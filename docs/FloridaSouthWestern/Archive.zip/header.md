## Site title (change by editing `header.md`)

<!-- Want a banner image? Find the image you want and store it in the images directory with the name `banner.jpg`. (Or you can modify the file name in the next line, with any image URL you want. -->

![](images/banner.jpg){img:height="300px" width="100%"}
<!-- If you don't want a banner, delete the previous line.  -->

**Menu**: [Schedule](schedule.md) : [Assignments](assignments.md) : [Data sets](datasets.md) 
